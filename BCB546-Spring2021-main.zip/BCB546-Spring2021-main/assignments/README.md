## Course Assignments

Each of the unit assignments are described by README files in their respective folders.  Folders also contain any files necessary for assignments.